README

This MSVC folder contains the Win32 Visual C projects FEC8.dll and FEC16.dll.

Compiling: The easiest way to compile these libraries is to use the project files in Microsoft Visual C++. Open the "FEC_dlls.dsw" workspace file in MSVC++, and everything else should load OK. The projects contain the compile settings ("Project->Settings...").

Notes:
1. The files will be compiled using the Microsoft C compiler (not C++).
2. The workspace contains 2 projects. To compile, set the active project first (Project->Set Active Project->...). Then choose "Build->Rebuild All".
3. The files get compiled to the "Debug" directory. Copy and paste the files to the correct location.
4. If you are calling these .dlls from Java code, you can put the .dll file in the same folder as the java .class file and it will be found without any environment variable settings.
5. The .dll's are located using the native-lib.properties file, which should contain something similar to the following:

	com.swarmcast.nativelib.keys=fec8,fec16

	com.swarmcast.nativelib.fec8=lib/win32/fec8.dll
	com.swarmcast.nativelib.fec16=lib/win32/fec16.dll

6. At the time of this writing, the JNI C-code is the same for both Windows and Linux. Type "make" in the Swarmcast/FEC/src/csrc directory to compile for Linux (using the makefile in that directory).

7. Note that the fec.c file contains a conditional statement "#ifdef MSDOS". Depending on the deployment approach for the FEC, this must be considered for successful compilation. Of course "MSDOS" is for win32 platforms.


--------------------------------------------------------------------------------
This file created: March 21, 2001 for OpenCola by Todd Hiltz (todd@opencola.com)